import birdSpikesImg from "@/assets/bird-spikes.jpg";
import invisibleGrillImg from "@/assets/invisible-grill.jpg";
import birdNettingImg from "@/assets/bird-netting.jpg";
import cricketNetImg from "@/assets/cricket-net.jpg";
import grassNetImg from "@/assets/grass-net.jpg";
import balconySafetyImg from "@/assets/balcony-safety.jpg";

export interface Service {
  id: string;
  name: string;
  shortDescription: string;
  description: string;
  image: string;
  icon: string;
  benefits: string[];
  installationSteps: string[];
  price: string;
}

export const services: Service[] = [
  {
    id: "bird-spikes",
    name: "Bird Spikes Installation",
    shortDescription: "Prevent pigeons from landing on ledges, balconies, and rooftops with humane bird spikes.",
    description: "Bird spikes prevent pigeons from landing on ledges, balconies, and rooftops. Our professional-grade spikes are designed to be humane and highly effective, providing long-lasting protection against bird infestations.",
    image: birdSpikesImg,
    icon: "Shield",
    benefits: ["No harm to birds", "Long lasting protection", "Easy installation", "Weather resistant"],
    installationSteps: ["Site inspection & measurement", "Surface preparation & cleaning", "Spike strip placement", "Quality check & warranty"],
    price: "₹45/ft",
  },
  {
    id: "invisible-grill",
    name: "Invisible Balcony Grill",
    shortDescription: "Stainless steel wire grills for balcony safety and bird protection with a modern look.",
    description: "Invisible grills are stainless steel wires installed in balconies for safety and bird protection. They provide an unobstructed view while ensuring complete safety for children and preventing bird entry.",
    image: invisibleGrillImg,
    icon: "Eye",
    benefits: ["Strong stainless steel cable", "Child safety", "Bird prevention", "Modern aesthetic look"],
    installationSteps: ["Balcony measurement", "Custom frame design", "Wire tensioning & installation", "Safety testing"],
    price: "₹120/sqft",
  },
  {
    id: "bird-netting",
    name: "Bird Netting",
    shortDescription: "High-quality bird nets for balconies, windows, and open areas to keep birds away.",
    description: "Professional bird netting solutions for residential and commercial properties. Our HDPE nets are UV-stabilized and designed to last for years while providing complete bird protection.",
    image: birdNettingImg,
    icon: "Grid3x3",
    benefits: ["UV stabilized nets", "Durable HDPE material", "Custom sizes available", "Nearly invisible"],
    installationSteps: ["Area assessment", "Net size customization", "Frame & hook installation", "Net fixing & tensioning"],
    price: "₹25/sqft",
  },
  {
    id: "cricket-ground-net",
    name: "Cricket Ground Netting",
    shortDescription: "Large protective nets for cricket grounds and stadiums to prevent bird disturbance.",
    description: "Installation of large bird nets for cricket grounds and stadiums. Our heavy-duty netting solutions protect players, prevent bird disturbance, and maintain the quality of sports facilities.",
    image: cricketNetImg,
    icon: "Trophy",
    benefits: ["Protect players", "Prevent bird disturbance", "Durable HDPE nets", "Custom ground coverage"],
    installationSteps: ["Ground survey & planning", "Pole & structure setup", "Net deployment", "Anchoring & maintenance plan"],
    price: "₹15/sqft",
  },
  {
    id: "grass-protection-net",
    name: "Grass Protection Net",
    shortDescription: "Protect lawns, parks, and sports fields from birds and animals with durable nets.",
    description: "Protect grass from birds and animals in parks, gardens, and sports fields. Our UV-resistant, weatherproof netting keeps your green spaces pristine and well-maintained.",
    image: grassNetImg,
    icon: "TreePine",
    benefits: ["UV resistant", "Weather proof", "Strong netting material", "Eco-friendly solution"],
    installationSteps: ["Lawn area mapping", "Support structure setup", "Net laying & securing", "Edge sealing"],
    price: "₹12/sqft",
  },
  {
    id: "balcony-bird-safety",
    name: "Balcony Bird Safety",
    shortDescription: "Complete balcony protection with nets, invisible grills, and mesh for apartments.",
    description: "Comprehensive balcony bird safety solutions for apartments and flats. We offer a combination of pigeon nets, invisible grills, and mesh protection tailored to your balcony design.",
    image: balconySafetyImg,
    icon: "Home",
    benefits: ["Pigeon prevention", "Complete balcony coverage", "Invisible protection", "Customized solutions"],
    installationSteps: ["Balcony inspection", "Solution recommendation", "Custom installation", "Post-installation support"],
    price: "₹30/sqft",
  },
];
