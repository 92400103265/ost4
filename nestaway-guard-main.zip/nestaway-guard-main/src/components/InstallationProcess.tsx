import { motion } from "framer-motion";
import { Search, Lightbulb, Wrench, Headphones } from "lucide-react";

const steps = [
  { icon: Search, title: "Inspection", desc: "We assess your property to understand the bird problem." },
  { icon: Lightbulb, title: "Solution Planning", desc: "Custom solution designed based on your needs and budget." },
  { icon: Wrench, title: "Installation", desc: "Professional installation by our trained technicians." },
  { icon: Headphones, title: "Maintenance Support", desc: "Ongoing support and maintenance for lasting results." },
];

const InstallationProcess = () => (
  <section className="py-20 bg-muted">
    <div className="container mx-auto px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-14"
      >
        <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">Installation Process</h2>
        <p className="text-muted-foreground max-w-xl mx-auto">Simple 4-step process from inspection to complete installation.</p>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {steps.map((s, i) => (
          <motion.div
            key={s.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.15 }}
            className="text-center relative"
          >
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary text-primary-foreground mb-4 text-xl font-bold shadow-hero">
              <s.icon className="h-7 w-7" />
            </div>
            <div className="absolute top-8 left-1/2 w-full h-0.5 bg-border hidden lg:block" style={{ display: i === 3 ? 'none' : undefined }} />
            <p className="text-xs font-bold text-primary mb-1">Step {i + 1}</p>
            <h3 className="font-heading font-bold text-lg text-foreground mb-2">{s.title}</h3>
            <p className="text-sm text-muted-foreground">{s.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default InstallationProcess;
