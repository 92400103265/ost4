import { motion } from "framer-motion";
import { Star } from "lucide-react";

const testimonials = [
  { name: "Priya Sharma", service: "Balcony Bird Netting", text: "Excellent service! The team installed bird nets on all our balconies within a few hours. No more pigeon problems!", rating: 5 },
  { name: "Rajesh Kumar", service: "Bird Spikes Installation", text: "Very professional and clean work. The bird spikes are barely visible and extremely effective. Highly recommended!", rating: 5 },
  { name: "Anita Desai", service: "Invisible Grill", text: "The invisible grill looks amazing on our balcony. It provides safety for our kids and keeps birds out. Great investment!", rating: 4 },
];

const Testimonials = () => (
  <section className="py-20 bg-background">
    <div className="container mx-auto px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-14"
      >
        <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">Customer Testimonials</h2>
        <p className="text-muted-foreground max-w-xl mx-auto">See what our satisfied customers have to say.</p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {testimonials.map((t, i) => (
          <motion.div
            key={t.name}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="bg-card rounded-xl p-6 border border-border shadow-card"
          >
            <div className="flex gap-1 mb-3">
              {Array.from({ length: 5 }).map((_, si) => (
                <Star key={si} className={`h-4 w-4 ${si < t.rating ? "fill-primary text-primary" : "text-border"}`} />
              ))}
            </div>
            <p className="text-sm text-muted-foreground mb-4 italic leading-relaxed">"{t.text}"</p>
            <div>
              <p className="font-heading font-semibold text-card-foreground">{t.name}</p>
              <p className="text-xs text-muted-foreground">{t.service}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default Testimonials;
