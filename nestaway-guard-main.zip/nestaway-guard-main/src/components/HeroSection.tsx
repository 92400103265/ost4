import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, ShieldCheck } from "lucide-react";
import heroBg from "@/assets/hero-bg.jpg";

const HeroSection = () => (
  <section className="relative min-h-[90vh] flex items-center overflow-hidden">
    <div className="absolute inset-0">
      <img src={heroBg} alt="Bird net installation" className="w-full h-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-r from-charcoal/90 via-charcoal/70 to-charcoal/40" />
    </div>

    <div className="container mx-auto px-4 relative z-10 py-20">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="max-w-2xl"
      >
        <div className="inline-flex items-center gap-2 bg-primary/20 border border-primary/30 rounded-full px-4 py-2 mb-6">
          <ShieldCheck className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium text-primary-foreground/90">Trusted Bird Protection Experts</span>
        </div>

        <h1 className="font-heading text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight mb-6" style={{ color: 'white' }}>
          Professional Bird<br />
          <span className="text-primary">Control Services</span>
        </h1>

        <p className="text-lg md:text-xl mb-8 leading-relaxed" style={{ color: 'rgba(255,255,255,0.8)' }}>
          Safe and humane bird protection solutions for homes, offices, and sports facilities. Protect your property with expert installation.
        </p>

        <div className="flex flex-wrap gap-4">
          <Link
            to="/contact"
            className="inline-flex items-center gap-2 bg-primary hover:bg-nature-dark text-primary-foreground font-semibold px-8 py-4 rounded-lg transition-all shadow-hero hover:shadow-elevated"
          >
            Get Free Inspection <ArrowRight className="h-5 w-5" />
          </Link>
          <Link
            to="/services"
            className="inline-flex items-center gap-2 border-2 border-primary-foreground/30 hover:border-primary text-primary-foreground font-semibold px-8 py-4 rounded-lg transition-all hover:bg-primary/10"
          >
            Our Services
          </Link>
        </div>
      </motion.div>
    </div>
  </section>
);

export default HeroSection;
