import { motion } from "framer-motion";
import { ShieldCheck, Clock, Award, HeartHandshake } from "lucide-react";

const reasons = [
  { icon: ShieldCheck, title: "Safe & Humane", desc: "All our solutions are bird-friendly and cause no harm." },
  { icon: Clock, title: "Quick Installation", desc: "Professional setup completed in hours, not days." },
  { icon: Award, title: "Quality Materials", desc: "UV-resistant, weatherproof, and long-lasting products." },
  { icon: HeartHandshake, title: "Customer First", desc: "Free inspections, fair pricing, and ongoing support." },
];

const WhyChooseUs = () => (
  <section className="py-20 bg-nature-light">
    <div className="container mx-auto px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-14"
      >
        <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">Why Choose Us</h2>
        <p className="text-muted-foreground max-w-xl mx-auto">
          Trusted by hundreds of homeowners and businesses across India for reliable bird control solutions.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {reasons.map((r, i) => (
          <motion.div
            key={r.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="bg-card rounded-xl p-6 text-center shadow-card"
          >
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-primary/10 mb-4">
              <r.icon className="h-7 w-7 text-primary" />
            </div>
            <h3 className="font-heading font-bold text-lg mb-2 text-card-foreground">{r.title}</h3>
            <p className="text-sm text-muted-foreground">{r.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default WhyChooseUs;
