import { Link } from "react-router-dom";
import { Bird, Phone, Mail, MapPin } from "lucide-react";

const Footer = () => (
  <footer className="bg-charcoal text-muted py-16">
    <div className="container mx-auto px-4">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
        {/* Brand */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Bird className="h-7 w-7 text-primary" />
            <span className="font-heading font-bold text-lg text-background">
              Bird Control Service
            </span>
          </div>
          <p className="text-sm leading-relaxed opacity-70">
            Professional bird control and safety solutions. Safe, humane, and effective protection for your property.
          </p>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="font-heading font-semibold text-background mb-4">Quick Links</h4>
          <div className="flex flex-col gap-2">
            {["Home", "About", "Services", "Gallery", "Pricing", "Contact"].map((l) => (
              <Link key={l} to={l === "Home" ? "/" : `/${l.toLowerCase()}`} className="text-sm opacity-70 hover:opacity-100 hover:text-primary transition-all">
                {l}
              </Link>
            ))}
          </div>
        </div>

        {/* Services */}
        <div>
          <h4 className="font-heading font-semibold text-background mb-4">Services</h4>
          <div className="flex flex-col gap-2 text-sm opacity-70">
            <span>Bird Spikes Installation</span>
            <span>Invisible Balcony Grill</span>
            <span>Bird Netting</span>
            <span>Cricket Ground Netting</span>
            <span>Grass Protection Net</span>
            <span>Balcony Bird Safety</span>
          </div>
        </div>

        {/* Contact */}
        <div>
          <h4 className="font-heading font-semibold text-background mb-4">Contact Info</h4>
          <div className="flex flex-col gap-3 text-sm">
            <a href="tel:+919876543210" className="flex items-center gap-2 opacity-70 hover:opacity-100 transition-opacity">
              <Phone className="h-4 w-4 text-primary" /> +91 9876543210
            </a>
            <a href="mailto:info@birdcontrolservice.com" className="flex items-center gap-2 opacity-70 hover:opacity-100 transition-opacity">
              <Mail className="h-4 w-4 text-primary" /> info@birdcontrolservice.com
            </a>
            <span className="flex items-center gap-2 opacity-70">
              <MapPin className="h-4 w-4 text-primary" /> India
            </span>
          </div>
        </div>
      </div>

      <div className="mt-12 pt-8 border-t border-muted-foreground/20 text-center text-sm opacity-50">
        © {new Date().getFullYear()} Bird Control Service. All rights reserved.
      </div>
    </div>
  </footer>
);

export default Footer;
