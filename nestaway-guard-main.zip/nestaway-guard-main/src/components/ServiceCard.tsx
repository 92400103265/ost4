import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Shield, Eye, Grid3x3, Trophy, TreePine, Home } from "lucide-react";
import type { Service } from "@/data/services";

const iconMap: Record<string, React.ElementType> = {
  Shield, Eye, Grid3x3, Trophy, TreePine, Home,
};

const ServiceCard = ({ service, index }: { service: Service; index: number }) => {
  const Icon = iconMap[service.icon] || Shield;

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1 }}
    >
      <Link
        to={`/services/${service.id}`}
        className="group block bg-card rounded-xl border border-border shadow-card hover:shadow-elevated transition-all duration-300 overflow-hidden hover:-translate-y-1"
      >
        <div className="h-48 overflow-hidden">
          <img
            src={service.image}
            alt={service.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        </div>
        <div className="p-6">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-lg bg-nature-light mb-4">
            <Icon className="h-6 w-6 text-primary" />
          </div>
          <h3 className="font-heading font-bold text-lg mb-2 text-card-foreground group-hover:text-primary transition-colors">
            {service.name}
          </h3>
          <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
            {service.shortDescription}
          </p>
          <span className="inline-flex items-center gap-1 text-sm font-semibold text-primary">
            Read More <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </span>
        </div>
      </Link>
    </motion.div>
  );
};

export default ServiceCard;
