import { motion } from "framer-motion";
import { services } from "@/data/services";

const Gallery = () => (
  <div className="pt-20">
    <section className="py-20 bg-nature-light">
      <div className="container mx-auto px-4 text-center">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="font-heading text-4xl md:text-5xl font-bold text-foreground mb-4">Gallery</h1>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Browse our portfolio of professional bird control installations.
          </p>
        </motion.div>
      </div>
    </section>

    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s, i) => (
            <motion.div
              key={s.id}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group relative rounded-xl overflow-hidden shadow-card aspect-[4/3]"
            >
              <img
                src={s.image}
                alt={s.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-charcoal/0 group-hover:bg-charcoal/60 transition-all duration-300 flex items-end">
                <div className="p-6 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                  <h3 className="font-heading font-bold text-lg" style={{ color: 'white' }}>{s.name}</h3>
                  <p className="text-sm" style={{ color: 'rgba(255,255,255,0.8)' }}>{s.shortDescription}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  </div>
);

export default Gallery;
