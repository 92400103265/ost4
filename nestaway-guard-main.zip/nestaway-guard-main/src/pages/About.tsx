import { motion } from "framer-motion";
import { ShieldCheck, Users, MapPin, Award } from "lucide-react";

const stats = [
  { icon: Users, value: "500+", label: "Happy Clients" },
  { icon: MapPin, value: "50+", label: "Cities Covered" },
  { icon: Award, value: "10+", label: "Years Experience" },
  { icon: ShieldCheck, value: "1000+", label: "Installations" },
];

const About = () => (
  <div className="pt-20">
    <section className="py-20 bg-nature-light">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-3xl mx-auto text-center">
          <h1 className="font-heading text-4xl md:text-5xl font-bold text-foreground mb-6">About Bird Control Service</h1>
          <p className="text-lg text-muted-foreground leading-relaxed">
            We are India's trusted provider of humane bird control solutions. With over a decade of experience, we protect homes, offices, and sports facilities from bird-related problems using safe, effective, and eco-friendly methods.
          </p>
        </motion.div>
      </div>
    </section>

    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="text-center p-6"
            >
              <s.icon className="h-8 w-8 text-primary mx-auto mb-3" />
              <p className="font-heading text-3xl font-bold text-foreground">{s.value}</p>
              <p className="text-sm text-muted-foreground">{s.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>

    <section className="py-16 bg-muted">
      <div className="container mx-auto px-4 max-w-3xl">
        <h2 className="font-heading text-2xl font-bold text-foreground mb-6 text-center">Our Mission</h2>
        <p className="text-muted-foreground leading-relaxed text-center">
          To provide safe, humane, and effective bird control solutions that protect properties while respecting wildlife. We believe in sustainable methods that create harmony between urban living and nature.
        </p>
      </div>
    </section>
  </div>
);

export default About;
