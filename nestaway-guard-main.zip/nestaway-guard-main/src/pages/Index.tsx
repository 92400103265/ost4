import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import HeroSection from "@/components/HeroSection";
import ServiceCard from "@/components/ServiceCard";
import WhyChooseUs from "@/components/WhyChooseUs";
import Testimonials from "@/components/Testimonials";
import InstallationProcess from "@/components/InstallationProcess";
import { services } from "@/data/services";

const Index = () => (
  <>
    <HeroSection />

    {/* Services Overview */}
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-14">
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">Our Services</h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Comprehensive bird control solutions for every property type.
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s, i) => (
            <ServiceCard key={s.id} service={s} index={i} />
          ))}
        </div>
      </div>
    </section>

    <WhyChooseUs />
    <InstallationProcess />
    <Testimonials />

    {/* CTA */}
    <section className="py-20 bg-primary">
      <div className="container mx-auto px-4 text-center">
        <h2 className="font-heading text-3xl md:text-4xl font-bold text-primary-foreground mb-4">
          Ready to Protect Your Property?
        </h2>
        <p className="text-primary-foreground/80 max-w-xl mx-auto mb-8">
          Get a free inspection and customized bird control solution today.
        </p>
        <Link
          to="/contact"
          className="inline-flex items-center gap-2 bg-background text-foreground font-semibold px-8 py-4 rounded-lg shadow-elevated hover:shadow-hero transition-all"
        >
          Contact Us Now <ArrowRight className="h-5 w-5" />
        </Link>
      </div>
    </section>
  </>
);

export default Index;
