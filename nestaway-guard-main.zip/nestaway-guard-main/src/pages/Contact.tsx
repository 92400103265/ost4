import { useState } from "react";
import { motion } from "framer-motion";
import { Phone, Mail, MapPin, Send } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";

const contactSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100),
  phone: z.string().trim().min(10, "Valid phone required").max(15),
  email: z.string().trim().email("Valid email required").max(255),
  serviceType: z.string().min(1, "Select a service"),
  message: z.string().trim().min(1, "Message is required").max(1000),
});

const serviceOptions = [
  "Bird Spikes Installation",
  "Invisible Balcony Grill",
  "Bird Netting",
  "Cricket Ground Netting",
  "Grass Protection Net",
  "Balcony Bird Safety",
  "Other",
];

const Contact = () => {
  const [form, setForm] = useState({ name: "", phone: "", email: "", serviceType: "", message: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = contactSchema.safeParse(form);
    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.errors.forEach((err) => {
        if (err.path[0]) fieldErrors[err.path[0] as string] = err.message;
      });
      setErrors(fieldErrors);
      return;
    }
    setErrors({});
    toast.success("Thank you! We'll get back to you shortly.");
    setForm({ name: "", phone: "", email: "", serviceType: "", message: "" });
  };

  const inputClass = (field: string) =>
    `w-full px-4 py-3 rounded-lg border ${errors[field] ? "border-destructive" : "border-border"} bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 transition-all`;

  return (
    <div className="pt-20">
      <section className="py-20 bg-nature-light">
        <div className="container mx-auto px-4 text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <h1 className="font-heading text-4xl md:text-5xl font-bold text-foreground mb-4">Contact Us</h1>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Get a free inspection and quote for your bird control needs.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-5xl mx-auto">
            {/* Form */}
            <motion.form
              onSubmit={handleSubmit}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-5"
            >
              <div>
                <input placeholder="Your Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputClass("name")} />
                {errors.name && <p className="text-destructive text-xs mt-1">{errors.name}</p>}
              </div>
              <div>
                <input placeholder="Phone Number" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className={inputClass("phone")} />
                {errors.phone && <p className="text-destructive text-xs mt-1">{errors.phone}</p>}
              </div>
              <div>
                <input placeholder="Email Address" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className={inputClass("email")} />
                {errors.email && <p className="text-destructive text-xs mt-1">{errors.email}</p>}
              </div>
              <div>
                <select value={form.serviceType} onChange={(e) => setForm({ ...form, serviceType: e.target.value })} className={inputClass("serviceType")}>
                  <option value="">Select Service Type</option>
                  {serviceOptions.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
                {errors.serviceType && <p className="text-destructive text-xs mt-1">{errors.serviceType}</p>}
              </div>
              <div>
                <textarea placeholder="Your Message" rows={4} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className={inputClass("message")} />
                {errors.message && <p className="text-destructive text-xs mt-1">{errors.message}</p>}
              </div>
              <button type="submit" className="inline-flex items-center gap-2 bg-primary text-primary-foreground font-semibold px-8 py-4 rounded-lg shadow-hero hover:bg-nature-dark transition-all w-full justify-center">
                <Send className="h-5 w-5" /> Send Message
              </button>
            </motion.form>

            {/* Contact Info */}
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-8">
              <div>
                <h3 className="font-heading font-bold text-xl text-foreground mb-6">Get In Touch</h3>
                <div className="space-y-4">
                  <a href="tel:+919876543210" className="flex items-center gap-4 p-4 bg-muted rounded-lg hover:bg-nature-light transition-colors">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center"><Phone className="h-5 w-5 text-primary" /></div>
                    <div><p className="text-sm text-muted-foreground">Phone</p><p className="font-semibold text-foreground">+91 9876543210</p></div>
                  </a>
                  <a href="mailto:info@birdcontrolservice.com" className="flex items-center gap-4 p-4 bg-muted rounded-lg hover:bg-nature-light transition-colors">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center"><Mail className="h-5 w-5 text-primary" /></div>
                    <div><p className="text-sm text-muted-foreground">Email</p><p className="font-semibold text-foreground">info@birdcontrolservice.com</p></div>
                  </a>
                  <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center"><MapPin className="h-5 w-5 text-primary" /></div>
                    <div><p className="text-sm text-muted-foreground">Location</p><p className="font-semibold text-foreground">India</p></div>
                  </div>
                </div>
              </div>

              {/* Map placeholder */}
              <div className="rounded-xl overflow-hidden border border-border shadow-card">
                <iframe
                  title="Location"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3783065.3548498047!2d73.71394835!3d20.5937767!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30635ff06b92b791%3A0xd78c4fa1854213a6!2sIndia!5e0!3m2!1sen!2sin!4v1700000000000"
                  width="100%"
                  height="250"
                  style={{ border: 0 }}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
