import { useParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, CheckCircle2, ArrowRight } from "lucide-react";
import { services } from "@/data/services";

const ServiceDetails = () => {
  const { id } = useParams();
  const service = services.find((s) => s.id === id);

  if (!service) {
    return (
      <div className="pt-20 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-heading text-2xl font-bold mb-4">Service Not Found</h1>
          <Link to="/services" className="text-primary font-semibold">Back to Services</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20">
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <Link to="/services" className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary mb-8 transition-colors">
            <ArrowLeft className="h-4 w-4" /> Back to Services
          </Link>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
              <img src={service.image} alt={service.name} className="w-full rounded-xl shadow-elevated object-cover aspect-[4/3]" />
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
              <h1 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">{service.name}</h1>
              <p className="text-muted-foreground leading-relaxed mb-6">{service.description}</p>
              <p className="text-2xl font-heading font-bold text-primary mb-6">Starting from {service.price}</p>

              <h3 className="font-heading font-bold text-lg mb-3">Benefits</h3>
              <ul className="space-y-2 mb-8">
                {service.benefits.map((b) => (
                  <li key={b} className="flex items-center gap-2 text-muted-foreground">
                    <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0" /> {b}
                  </li>
                ))}
              </ul>

              <h3 className="font-heading font-bold text-lg mb-3">Installation Steps</h3>
              <ol className="space-y-2 mb-8">
                {service.installationSteps.map((s, i) => (
                  <li key={s} className="flex items-center gap-3 text-muted-foreground">
                    <span className="flex-shrink-0 w-7 h-7 rounded-full bg-primary text-primary-foreground text-sm font-bold flex items-center justify-center">{i + 1}</span>
                    {s}
                  </li>
                ))}
              </ol>

              <Link
                to="/contact"
                className="inline-flex items-center gap-2 bg-primary text-primary-foreground font-semibold px-8 py-4 rounded-lg shadow-hero hover:bg-nature-dark transition-all"
              >
                Get Quote <ArrowRight className="h-5 w-5" />
              </Link>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ServiceDetails;
