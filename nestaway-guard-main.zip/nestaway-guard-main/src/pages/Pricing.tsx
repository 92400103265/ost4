import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Check } from "lucide-react";

const plans = [
  {
    name: "Basic",
    price: "₹2,999",
    description: "Balcony Net Installation",
    features: ["Single balcony coverage", "HDPE bird net", "Standard installation", "1-year warranty"],
    popular: false,
  },
  {
    name: "Standard",
    price: "₹6,999",
    description: "Bird Spikes + Balcony Net",
    features: ["Bird spikes installation", "Balcony net installation", "Premium materials", "2-year warranty", "Free maintenance visit"],
    popular: true,
  },
  {
    name: "Premium",
    price: "₹14,999",
    description: "Complete Bird Protection",
    features: ["Full property assessment", "All access points covered", "Invisible grills included", "3-year warranty", "Annual maintenance", "Priority support"],
    popular: false,
  },
];

const Pricing = () => (
  <div className="pt-20">
    <section className="py-20 bg-nature-light">
      <div className="container mx-auto px-4 text-center">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="font-heading text-4xl md:text-5xl font-bold text-foreground mb-4">Pricing Plans</h1>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Affordable bird control solutions for every budget.
          </p>
        </motion.div>
      </div>
    </section>

    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {plans.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className={`rounded-xl p-8 border ${
                plan.popular
                  ? "border-primary bg-primary/5 shadow-hero scale-105"
                  : "border-border bg-card shadow-card"
              } relative`}
            >
              {plan.popular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-xs font-bold px-4 py-1 rounded-full">
                  Most Popular
                </span>
              )}
              <h3 className="font-heading font-bold text-xl mb-1 text-foreground">{plan.name}</h3>
              <p className="text-sm text-muted-foreground mb-4">{plan.description}</p>
              <p className="font-heading text-4xl font-extrabold text-foreground mb-6">
                {plan.price}<span className="text-base font-normal text-muted-foreground">/starting</span>
              </p>
              <ul className="space-y-3 mb-8">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Check className="h-4 w-4 text-primary flex-shrink-0" /> {f}
                  </li>
                ))}
              </ul>
              <Link
                to="/contact"
                className={`block text-center font-semibold py-3 rounded-lg transition-all ${
                  plan.popular
                    ? "bg-primary text-primary-foreground hover:bg-nature-dark shadow-hero"
                    : "bg-muted text-foreground hover:bg-primary hover:text-primary-foreground"
                }`}
              >
                Book Now
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  </div>
);

export default Pricing;
